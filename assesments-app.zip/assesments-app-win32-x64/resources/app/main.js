const electron = require("electron");
const url = require("url");
const path = require("path");
const { on } = require("events");


const { app, autoUpdater, dialog, BrowserWindow } = electron;

let mainWindow;

//Once app is ready

app.on("ready", () => {
    console.log(app.getVersion());
    mainWindow = new BrowserWindow({
        webPreferences: {
            nodeIntegration: true,
            contextIsolation: false
        },
        width: 1200,
        height: 700,
        resizable: true
    });

    mainWindow.setTitle("AssesmentsApp");

    //load html
    mainWindow.loadURL(url.format({
        pathname: path.join(__dirname, "/template/index.html"),
        protocol: "file:",
        slashes: true
    }))
})