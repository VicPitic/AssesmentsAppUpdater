const fs = require("fs");

const firebaseConfig = {
    apiKey: "AIzaSyBfCryHd1wS24fJJ6B_PKTjDCaEtoTVlPs",
    authDomain: "assesmentsapp.firebaseapp.com",
    projectId: "assesmentsapp",
    storageBucket: "assesmentsapp.appspot.com",
    messagingSenderId: "179896236410",
    appId: "1:179896236410:web:8f6605468ce28a168f7ec3",
    measurementId: "G-GFVYZ7TTBK"
};


const versionRaw = fs.readFileSync("template/db/version_type.json");
const version = JSON.parse(versionRaw);

const versionButton = document.getElementById("new-version-button");

console.log(version["my_version"])

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.analytics();

var storage = firebase.storage();
var pathReference = storage.ref().child("app_versions/Assesments App.zip");

const dbRef = firebase.database().ref();
dbRef.child("app_version").child("version").get().then((snapshot) => {
    if (snapshot.exists()) {
        if (snapshot.val() != version["my_version"]) {
            console.log(snapshot.val());

            let version_url = `https://firebasestorage.googleapis.com/v0/b/assesmentsapp.appspot.com/o/app_versions%2Fapp_versions%2FAssesments%20App.zip?alt=media&token=acf7c177-20da-484d-9527-8359427045c9`;

            versionButton.innerHTML = "You are not up to date. Download latest version";
            versionButton.onclick = () => {
                version["my_version"] = 10;
                window.location = version_url;
            }
        }
        else
            versionButton.innerHTML = "You are up to date!";

    } else {
        console.log("No data available");
    }
}).catch((error) => {
    console.error(error);
});

